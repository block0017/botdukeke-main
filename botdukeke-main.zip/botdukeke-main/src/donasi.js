const donasi = () => {
	return `

┏━━━━━━━━━━━━━━━━━━━━
┃          nao da pra doar pro keke
┣━━━━━━━━━━━━━━━━━━━━

`
}

exports.donasi = donasi
