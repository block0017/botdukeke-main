
const help = (prefix) => { 
	return `                 
<═══════════════════════>
                      ᏴϴͲ ᎠႮ ᏦᎬᏦᎬ
 <═══════════════════════>

             ╲    ╱    ● ᏴϴͲ●ᎷᎬΝႮ●
       ╱▔▔▔▔▔╲       Author    : ՏᎡ.ᏦᎬᏦᎬ
      ┃┈▇┈┈▇┈┃      
╭╮┣━━━━━━┫╭╮    
┃┃┃┈┈┈┈┈┈┃┃┃    
╰╯┃┈┈┈┈┈┈┃╰╯
      ╰┓┏━━┓┏╯
         ╰╯      ╰╯

 ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
 
 ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
╔═════════════════════════╗
 ●─────────●MENU●──────────●
╚═════════════════════════╝

╔══════════════════════
║ ᏟϴᎷᎪΝᎠϴՏ ᏞᏆՏͲᎪᎠϴՏ
╠══════════════════════
║   ᎬХᏟᏞႮՏᏆᏙϴ ᏢᎪᎡᎪ ᎪᎠᎷ'Տ
║╭─────────────────────
║├────> ${prefix}kick @menciona o membro
║├> banir membro 
║├─────────────────────
║├> ${prefix}add +55xxxxxxxxx
║├────> add menbro
║├─────────────────────
║├> ${prefix}listadmin
║├────> listar cm todos ADM's
║├─────────────────────
║├> ${prefix}welcome [1/0]
║├────> ativar/desativar boas vindas
║├─────────────────────
║├> ${prefix}group tutup
║├────> fecha grupo 
║├─────────────────────
║├> ${prefix}group buka
║├────> abrir grupo 
║├─────────────────────
║├> ${prefix}demote @marca adm
║├────> retirar ADM de alguém
║├─────────────────────
║├> ${prefix}promote @marca membro
║├────> promover a ADM
║├─────────────────────
║├> ${prefix}nsfw [1/0]
║├────> ativa/desativar modo loli
║├─────────────────────
║├> ${prefix}simih [1/0]
║├────>  ??? Sla pra q serve 
║└─────────────────────
╠══════════════════════
║   ᎷᏆᎠᏆᎪ Ꮖ ՏͲᏆᏟᏦᎬᎡ
║╭─────────────────────
║├> ${prefix}sticker + foto/Gif
║├────> fazer figurinha
║├─────────────────────
║├> ${prefix}anjing
║├────> dog aleatório fofinho
║├─────────────────────
║├> ${prefix}text3d seu txt
║├────> uma foto cm seu txt
║├─────────────────────
║├> ${prefix}pokemon
║├────> um pokemon aleatório
║├─────────────────────
║├> ${prefix}ocr (marque uma foto)
║├────> pegar txts de uma foto
║├─────────────────────
║├> ${prefix}tts pt seu txt
║├────> transformar txt em áudio
║├─────────────────────
║├> ${prefix}toimg (marca uma fig)
║├────> converter fig em foto
║├─────────────────────
║├> ${prefix}ytmp4 (link de algum vídeo)
║├────> pega informações de vídeo
║├─────────────────────
║├> ${prefix}hilih seu txt
║├────> converter todas vogais do
║│ txt para "i"
║├─────────────────────
║├> ${prefix}quotes
║├────> txt de motivação (indo)
║├─────────────────────
║├> ${prefix}map 00000-000
║├────> pega imagem do local
║│desejado 
║├─────────────────────
║├> ${prefix}nsfwloli
║├────> foto de loli
║├─────────────────────
║├> ${prefix}loli
║├────> foto de loli
║├─────────────────────
║├> ${prefix}fototiktok
║├────> ??? Sla
║├─────────────────────
║├> ${prefix}phlogo seu|txt
║├────> logo do porn hub cm seu txt
║├─────────────────────
║├> ${prefix}tiktokstalk
║├────> ?? Não sei como funciona
║└─────────────────────
╠══════════════════════
║   ᏟϴᎷᎪΝᎠϴՏ ᏢᎪᎡᎪ ϴ ᏟᎡᏆᎪᎠϴᎡ
║╭─────────────────────
║├> ${prefix}clearall
║├────> sla
║├─────────────────────
║├> ${prefix}block
║├────> BLOQ em membro
║├─────────────────────
║├> ${prefix}bc
║├────> sla
║├─────────────────────
║├> ${prefix}leave
║├────> sla
║├─────────────────────
║├> ${prefix}setpp
║├────> sla
║├─────────────────────
║├> ${prefix}setprefix
║├────> mudar sigla
║└─────────────────────
╚═══════════════════════
ՏᎡ.ᏦᎬᏦᎬ ͲᎻᎬ ᏴᎬՏͲ❦ᵃᵗᵉⁿᵃ© 2021

`
}
exports.help = help



  
